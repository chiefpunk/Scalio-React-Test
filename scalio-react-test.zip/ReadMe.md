## Developments

**Install deps**

```sh
yarn install
```

**Start the project**

```sh
yarn start
```

## Contributions