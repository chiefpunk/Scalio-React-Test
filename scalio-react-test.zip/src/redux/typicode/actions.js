const actions = {
  SET_STATE: "typicode/SET_STATE",
  SET_NUMBER: "typicode/SET_NUMBER"
};

export default actions;
