import Typicode from "./typicode/reducer";

export default {
  Typicode
};
