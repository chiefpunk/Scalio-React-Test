export const API_ENDPOINT = "https://jsonplaceholder.typicode.com/";
